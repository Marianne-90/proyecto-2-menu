export { Home } from "./home/Home";
export { Menus } from "./menus/Menus";
export { Order } from "./order/Order";
export { WorkBox } from "./work-box/WorkBox";
export { ContactAndUbication } from "./contact-ubication/ContactAndUbication";

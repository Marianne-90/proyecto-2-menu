export const CONTACT_DATA = {
  mail: "strudelcafeteria@gmail.com",
  tel: 2224313966,
  cel: 2211717152,
  adress:
    "Av Orion Nte 501 F, Tlaxcalancingo, Sta Cruz Buenavista, 72810 San Andrés Cholula, Pue.",
  hours:
    "Lunes a Viernes de 7:30 am a 9:30 pm Sábados de 8:00 am a 5:00 pm Domingo cerrado",
  social: [
    {
      red: "facebook",
      name: "@StrudelOficial",
      src: "https://www.facebook.com/StrudelOficial",
    },
    {
      red: "instagram",
      name: "Instagram",
      src: "https://www.instagram.com/strudelcafeteriarestaurante/",
    },
  ],
};
